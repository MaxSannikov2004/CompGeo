"""Лабораторная работа 1 (опционально).

Если вам удобнее, можете реализовать функции в этом файле `lab1.py`,
а в ноутбуке просто импортировать их. Тесты сначала пытаются импортировать
`lab1.py`, а если его нет — берут реализации из ноутбука.
"""

EPS = 1e-9

def orient(A, B, C):
    raise NotImplementedError

def dist_point_line(P, a, b, c):
    raise NotImplementedError

def on_segment(A, B, P):
    raise NotImplementedError

def segments_intersect(A, B, C, D):
    raise NotImplementedError

def polygon_area(poly):
    raise NotImplementedError

def point_in_polygon(Q, poly):
    raise NotImplementedError
